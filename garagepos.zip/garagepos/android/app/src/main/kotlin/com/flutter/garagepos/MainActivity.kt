package com.flutter.garagepos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
