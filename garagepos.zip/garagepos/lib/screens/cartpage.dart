import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:garagepos/db/db_helper.dart';
import 'package:garagepos/model/salesorder_model.dart';
import 'package:garagepos/model/salesorderdetail_model.dart';
import 'package:garagepos/model/cart_model.dart';

class CartPage extends StatefulWidget {
  const CartPage({Key key}) : super(key: key);
  static const routename='/cartpage';

  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {

  final dbHelper = DBHelper.instance;
  String _ordername='Self';
  String _ordernotes='Thank you for the order.';
  final _ordernamecontroller = TextEditingController();
  final _ordernotescontroller=TextEditingController();

  /// the current time, in “seconds since the epoch”
  static int currentTimeInSeconds() {
    var ms = (new DateTime.now()).millisecondsSinceEpoch;
    return ms;
  }

  Future<void> _ackAlert(BuildContext context, String msg) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('New Order Request'),
          content: Text('$msg'),
          actions: <Widget>[
            TextButton(
              child: Text('Ok'),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushNamed(context, '/');
              },
            ),
          ],
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    setState(() {
      _ordernamecontroller.text=_ordername;
      _ordernotescontroller.text=_ordernotes;
    });
  }

  //SalesOrder(this.id,this.orderdatetime,this.name,this.email,this.phone,this.subtotal,this.taxamount,this.othercharges,this.ordertotal,this.updateddatetime,this.active);
  //SalesOrderDetail(this.id,this.orderid,this.orderlineitem,this.itemcode,this.itemname,this.qty,this.itemunit,this.itemprice,this.taxamount,this.itemnotes,this.createddatetime,this.updateddatetime,this.active);
  void _submitorderrequest() async {
    print(_ordername+' : '+_ordernotes);
    int len = 0;
    len = ScopedModel.of<CartModel>(context).cart.length;
    print('Total items: '+len.toString());
    if (len > 0) {
      double ordervalue = 0;
      ordervalue = ScopedModel
          .of<CartModel>(context)
          .totalCartValue;
      print('Order Value: ' + ordervalue.toString());
      final orderid=await dbHelper.addsalesorder(SalesOrder(null,currentTimeInSeconds(),_ordername,null,null,_ordernotes,0,0,0,ordervalue,currentTimeInSeconds(),1));
      print('DB Sales OrderID: '+orderid.toString());
      int i=0;
      ScopedModel
          .of<CartModel>(context)
          .cart
          .every((element) {
        print(element.id.toString()+' : '+element.itemname+' : '+element.itemprice.toString()+' : '+element.qty.toString());
        i++;
        final orderdetailid = dbHelper.addsalesorderdetail(SalesOrderDetail(null,orderid.id,i,element.id.toString(),element.itemname,element.qty,null,element.itemprice,0,null,currentTimeInSeconds(),currentTimeInSeconds(),1));
        return true;
      });
      print('Submitted order successfully.');
      ScopedModel.of<CartModel>(context).clearCart();
      dbHelper.getallsalesorders();
      dbHelper.getallsalesordersdetail();
      _ackAlert(context,
          'This order request is submitted successfully. Ref: '+orderid.id.toString());
    } else {
      print('Cart is empty.');
      _ackAlert(context, 'Cart is empty.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Text("Order Request Cart"),
          actions: <Widget>[
            TextButton(
                child: Text(
                  "Clear",
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () => ScopedModel.of<CartModel>(context).clearCart())
          ],
        ),
        body:ScopedModel.of<CartModel>(context, rebuildOnChange: true)
            .cart
            .length ==
            0
            ? Center(
          child: Text("No items in Cart"),
        )
            : Container(
            padding: EdgeInsets.all(8.0),
            child: Column(children: <Widget>[
              Row(
                children: <Widget>[
                  Text('Order Name:'),
                  SizedBox(
                    width: 2,
                  ),
                  Container(
                    width: 200,
                    height: 50,
                    child: Padding(
                      padding: EdgeInsets.all(5.0),
                      child: TextField(
                        onChanged: (String ordername) {
                          setState(() {
                            _ordername = ordername;
                          });
                        },
                        textAlign: TextAlign.start,
                        style: TextStyle(color: Colors.black),
                        controller: _ordernamecontroller,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                children: <Widget>[
                  Text('Order Notes:'),
                  SizedBox(
                    width: 2,
                  ),
                  Container(
                    width: 200,
                    height: 50,
                    child: Padding(
                      padding: EdgeInsets.all(5.0),
                      child: TextField(
                        onChanged: (String ordernotes) {
                          setState(() {
                            _ordernotes = ordernotes;
                          });
                        },
                        textAlign: TextAlign.start,
                        style: TextStyle(color: Colors.black),
                        controller: _ordernotescontroller,
                      ),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: ScopedModel.of<CartModel>(context,
                      rebuildOnChange: true)
                      .total,
                  itemBuilder: (context, index) {
                    return ScopedModelDescendant<CartModel>(
                      builder: (context, child, model) {
                        return ListTile(
                          title: Text(model.cart[index].itemname),
                          subtitle: Text(model.cart[index].qty.toString() +
                              " x " +
                              model.cart[index].itemprice.toString() +
                              " = " +
                              (model.cart[index].qty *
                                  model.cart[index].itemprice)
                                  .toString()),
                          trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: Icon(Icons.add),
                                  onPressed: () {
                                    model.updateProduct(model.cart[index],
                                        model.cart[index].qty + 1);
                                    // model.removeProduct(model.cart[index]);
                                  },
                                ),
                                IconButton(
                                  icon: Icon(Icons.remove),
                                  onPressed: () {
                                    model.updateProduct(model.cart[index],
                                        model.cart[index].qty - 1);
                                    // model.removeProduct(model.cart[index]);
                                  },
                                ),
                              ]),
                        );
                      },
                    );
                  },
                ),
              ),
              Container(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    "Order Total: \$ " +
                        ScopedModel.of<CartModel>(context,
                            rebuildOnChange: true)
                            .totalCartValue
                            .toString() +
                        "",
                    style: TextStyle(
                        fontSize: 20.0, fontWeight: FontWeight.bold),
                  )),
              SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blue, // background
                      onPrimary: Colors.white, // foreground
                    ),
                    child: Text(
                      "Submit Order Request",
                      textScaleFactor: 1.5,
                    ),
                    onPressed: () {
                      _submitorderrequest();
                    },
                  ))
            ])));  }
}
