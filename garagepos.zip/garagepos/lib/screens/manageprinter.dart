import 'package:flutter/material.dart';

class ManagePrinter extends StatefulWidget {
  static const routename='/manageprinter';

  @override
  _ManagePrinterState createState() => _ManagePrinterState();
}

class _ManagePrinterState extends State<ManagePrinter> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Printer',
          textAlign: TextAlign.center,),
      ),
    );
  }
}
