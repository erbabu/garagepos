import 'package:flutter/material.dart';

class About extends StatelessWidget {
  static const routename='/about';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About App',
          textAlign: TextAlign.center,),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text('This is a garage point of sale app. One can create items offered for sale with price, create an order, save and print the order for records. All data is stored in your phone.',
            textScaleFactor: 2,),
          ],
        ),
      ),
    );
  }
}
