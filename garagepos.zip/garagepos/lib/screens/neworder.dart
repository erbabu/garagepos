import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:garagepos/db/db_helper.dart';
import 'package:garagepos/model/cart_model.dart';
import 'package:garagepos/model/item_model.dart';
import 'package:garagepos/screens/cartpage.dart';
import 'package:scoped_model/scoped_model.dart';

class NewOrder extends StatefulWidget {
  static const routename='/neworder';

  @override
  _NewOrderState createState() => _NewOrderState();
}

class _NewOrderState extends State<NewOrder> {

  final dbHelper = DBHelper.instance;
  Future <List<Item>> items;
  CartModel cartinstance = new CartModel();

  void _showScaffold(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message),duration: Duration(seconds: 1),));
  }

  void _displayallitems() async {
    setState(() {
      items=dbHelper.getallitems();
    });
  }

  SingleChildScrollView _generateList (List<Item> items, CartModel model) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: SizedBox(
        width: MediaQuery.of(context).size.width,
        child: DataTable(columnSpacing: 50,
          columns: [
            DataColumn(label: Text('ItemName')),
            DataColumn(label: Text('ItemPrice')),
            DataColumn(label: Text('')),
            DataColumn(label: Text('')),
          ],
          rows: items.map((item) => DataRow(
            cells: [
              DataCell(Text(item.itemname),
              ),
              DataCell(Text(item.itemprice.toString()),
              ),
              DataCell(
                IconButton(
                  icon: Icon(Icons.add_shopping_cart),
                  onPressed: (){
                    Record cartrecord=new Record(item.id, item.itemname, item.itemprice, 1);
                    model.addProduct(cartrecord);
                    _showScaffold('Added to cart successfully');
                  },
                ),
              ),
              DataCell(
                IconButton(
                  icon: Icon(Icons.remove_shopping_cart_outlined),
                  onPressed: (){
                    Record cartrecord=new Record(item.id, item.itemname, item.itemprice, 1);
                    model.removeProduct(cartrecord);
                    _showScaffold('Removed from cart successfully');
                  },
                ),
              ),
            ],
          ),
          ).toList(),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _displayallitems();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('New Order Request',
          textAlign: TextAlign.center,),
        actions: <Widget> [
          IconButton(
              icon: Icon(Icons.shopping_cart),
              onPressed: () => Navigator.pushNamed(context,CartPage.routename)),
        ],
      ),
      body: ScopedModelDescendant<CartModel>(builder: (context, child, model) {
        return (Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget> [
            Expanded(
              child: FutureBuilder(
                future: items,
                builder: (context,snapshot){
                  if (snapshot.hasData){
                    return(_generateList(snapshot.data,model));
                  }
                  if (snapshot.data == null || snapshot.data.length == 0){
                    return Text('No Items Found');
                  }
                  return CircularProgressIndicator();
                },
              ),
            ),
          ],
        )
        );
      }),
    );
  }
}
