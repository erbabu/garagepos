import 'package:flutter/material.dart';
import 'package:garagepos/db/db_helper.dart';
import 'package:garagepos/model/item_model.dart';

class Items extends StatefulWidget {
  static const routename='/items';
  @override
  _ItemsState createState() => _ItemsState();
}

class _ItemsState extends State<Items> {

  final dbHelper = DBHelper.instance;
  final GlobalKey<FormState> _formStateKey = GlobalKey<FormState>();
  Future <List<Item>> items;
  String _itemname;
  double _itemprice;
  bool isUpdate = false;
  int itemIDforupdate;
  final _itemnamecontroller = TextEditingController();
  final _itempricecontroller=TextEditingController();

  /// the current time, in “seconds since the epoch”
  static int currentTimeInSeconds() {
    var ms = (new DateTime.now()).millisecondsSinceEpoch;
    return ms;
  }

  // Button onPressed methods
  void _insert() async {
    // row to insert
    final id = await dbHelper.additem(Item(null,null,_itemname,null,_itemprice,null,null, currentTimeInSeconds(),null,1));
    print('inserted row id: $id');
  }

  void _query() async {
    final allRows = await dbHelper.getallitems();
    print('query all rows:');
    allRows.forEach(print);
  }

  void _update(int id) async {
    final rowsAffected = await dbHelper.updateitem(Item(id,null,_itemname,null,_itemprice,null,null,currentTimeInSeconds(),null,1))
    .then((data){
      setState(() {
        isUpdate=false;
      });
    });
    print('updated $rowsAffected row(s)');
  }

  void _delete(int id) async {
    final rowsDeleted = await dbHelper.deleteitem(id);
    print('deleted $rowsDeleted row(s): row $id');
  }

  void _displayallitems() async {
    setState(() {
      items=dbHelper.getallitems();
    });
  }

  SingleChildScrollView _generateList (List<Item> items) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: SizedBox(
        width: MediaQuery.of(context).size.width,
        child: DataTable(
          columns: [
            DataColumn(label: Text('ItemName')),
            DataColumn(label: Text('ItemPrice')),
            DataColumn(label: Text('')),
          ],
          rows: items.map((item) => DataRow(
            cells: [
              DataCell(Text(item.itemname),
                onTap: (){
                  setState(() {
                    isUpdate=true;
                    itemIDforupdate=item.id;
                  });
                  _itemnamecontroller.text=item.itemname;
                  _itempricecontroller.text=item.itemprice.toString();
                },
              ),
              DataCell(Text(item.itemprice.toString()),
              onTap: (){
                setState(() {
                  isUpdate=true;
                  itemIDforupdate=item.id;
                });
               _itemnamecontroller.text=item.itemname;
               _itempricecontroller.text=item.itemprice.toString();
              },
              ),
              DataCell(
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: (){
                    //dbHelper.deleteitem(item.id);
                    _delete(item.id);
                    _itemnamecontroller.text='';
                    _itempricecontroller.text='';
                    _displayallitems();
                    final snackbar = SnackBar(content: Text('Deleted successfully'),);
                    ScaffoldMessenger.of(context).showSnackBar(snackbar);
                  },
                ),
              ),
            ],
          ),
          ).toList(),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _displayallitems();
    setState(() {
      isUpdate=false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Items',
          textAlign: TextAlign.center,),
        actions: <Widget> [
          ElevatedButton(onPressed: (){
            if (isUpdate) { //update
              if (_formStateKey.currentState.validate()) {
                _formStateKey.currentState.save();
                _update(itemIDforupdate);
                _itemnamecontroller.text='';
                _itempricecontroller.text='';
                _displayallitems();
                final snackbar = SnackBar(content: Text('Updated successfully'),);
                ScaffoldMessenger.of(context).showSnackBar(snackbar);
              }
            } else { //add
              if (_formStateKey.currentState.validate()) {
                _formStateKey.currentState.save();
                _insert();
                _itemnamecontroller.text='';
                _itempricecontroller.text='';
                _displayallitems();
                final snackbar = SnackBar(content: Text('Added successfully'),);
                ScaffoldMessenger.of(context).showSnackBar(snackbar);
              }
            }
          }, child: Text(
            (isUpdate ? 'UPDATE' : 'ADD'),
            style: TextStyle(color: Colors.white),
          )),
          ElevatedButton(onPressed: (){
            _itemnamecontroller.text='';
            _itempricecontroller.text='';
            setState(() {
              isUpdate=false;
              itemIDforupdate=null;
            });
          }, child: Text(
            (isUpdate ? 'CANCEL' : 'CLEAR'),
            style: TextStyle(color: Colors.white),
          ),),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Form(
              autovalidateMode: AutovalidateMode.always, key: _formStateKey,
                child: Column(
                  children: <Widget> [
                    Padding(
                      padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),
                      child: TextFormField(
                        onSaved: (value){
                          _itemname=value;
                        },
                        controller: _itemnamecontroller,
                        decoration: InputDecoration(
                          labelText: 'Item Name',
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),
                      child: TextFormField(
                        onSaved: (value){
                          _itemprice=double.parse(value.toString());
                        },
                        controller: _itempricecontroller,
                        decoration: InputDecoration(
                          labelText: 'Item Price',
                        ),
                      ),
                    ),
                  ],
                ),
            ),
            Expanded(
                child: FutureBuilder(
                  future: items,
                  builder: (context,snapshot){
                    if (snapshot.hasData){
                      return(_generateList(snapshot.data));
                    }
                    if (snapshot.data == null || snapshot.data.length == 0){
                      return Text('No Items Found');
                    }
                    return CircularProgressIndicator();
                  },
                ),
            ),
          ],
        ),
      ),
    );
  }
}
