import 'package:flutter/material.dart';

class ManageStore extends StatefulWidget {
  static const routename='/managestore';

  @override
  _ManageStoreState createState() => _ManageStoreState();
}

class _ManageStoreState extends State<ManageStore> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Store',
          textAlign: TextAlign.center,),
      ),
    );
  }
}
