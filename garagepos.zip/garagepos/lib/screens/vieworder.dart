import 'package:flutter/material.dart';

class ViewOrder extends StatefulWidget {
  static const routename='/vieworder';

  @override
  _ViewOrderState createState() => _ViewOrderState();
}

class _ViewOrderState extends State<ViewOrder> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Order Detail',
          textAlign: TextAlign.center,),
      ),
    );
  }
}
