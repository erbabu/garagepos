import 'package:flutter/material.dart';

class ManageEmail extends StatefulWidget {
  static const routename='/manageemail';

  @override
  _ManageEmailState createState() => _ManageEmailState();
}

class _ManageEmailState extends State<ManageEmail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Email',
          textAlign: TextAlign.center,),
      ),
    );
  }
}
