import 'package:flutter/material.dart';
import 'about.dart';
import 'items.dart';
import 'manageemail.dart';
import 'manageprinter.dart';
import 'managestore.dart';
import 'neworder.dart';
import 'orders.dart';
import 'vieworder.dart';
class AppMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          Container(
            padding: EdgeInsets.all(20),
            color: Theme.of(context).primaryColor,
            child: Center(
              child: Column(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    margin: EdgeInsets.only(top: 30,),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image:DecorationImage(image: AssetImage('assets/images/garagepos.png'),fit: BoxFit.fill,),
                    ),
                  ),
                ],
              ),
            ),
          ),
          ListTile(
            title: Text('New Order',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(NewOrder.routename);
            },
          ),
/*
          ListTile(
            title: Text('Orders',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(Orders.routename);
            },
          ),
          ListTile(
            title: Text('View Order',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(ViewOrder.routename);
            },
          ),
*/
          ListTile(
            title: Text('Items',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(Items.routename);
            },
          ),
/*
          ListTile(
            title: Text('Manage Store',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(ManageStore.routename);
            },
          ),
          ListTile(
            title: Text('Manage Email',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(ManageEmail.routename);
            },
          ),
          ListTile(
            title: Text('Manage Printer',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(ManagePrinter.routename);
            },
          ),
*/
          ListTile(
            title: Text('About',style: TextStyle(fontSize: 18),),
            onTap: (){
              Navigator.of(context).pushNamed(About.routename);
            },
          ),
        ],
      ),
    );
  }
}
