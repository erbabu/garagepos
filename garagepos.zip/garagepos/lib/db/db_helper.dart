import 'package:flutter/material.dart';
import 'package:garagepos/model/item_model.dart';
import 'package:garagepos/model/salesorder_model.dart';
import 'package:garagepos/model/salesorderdetail_model.dart';
import 'package:path/path.dart' show join;
import 'package:sqflite/sqflite.dart';
import 'dart:io' as io;
import 'package:path_provider/path_provider.dart' show getApplicationDocumentsDirectory;
import 'package:sqflite/utils/utils.dart';

class DBHelper {
  static final _databaseName = "garagepos.db";
  static final _databaseVersion = 1;
  // make this a singleton class
  DBHelper._privateConstructor();
  static final DBHelper instance = DBHelper._privateConstructor();

  static Database _db;
  Future<Database> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await initDatabase();
    return _db;
  }

  initDatabase() async {
    io.Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentDirectory.path, _databaseName);
    var db = await openDatabase(path, version: _databaseVersion, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    await db
        .execute("CREATE TABLE item (id INTEGER PRIMARY KEY, itemcode TEXT, itemname TEXT, itemunit TEXT, itemprice REAL, taxpercent REAL, available INTEGER, createddatetime NUMERIC DEFAULT (cast(strftime('%s','now') as int)), updateddatetime NUMERIC DEFAULT (cast(strftime('%s','now') as int)), active INTEGER DEFAULT 1)");
    await db
        .execute("CREATE TABLE salesorder (id INTEGER PRIMARY KEY, orderdatetime NUMERIC DEFAULT (cast(strftime('%s','now') as int)), name TEXT, email TEXT, phone TEXT, notes TEXT, subtotal REAL, taxamount REAL, othercharges REAL, ordertotal REAL, updateddatetime NUMERIC DEFAULT (cast(strftime('%s','now') as int)), active INTEGER DEFAULT 1)");
    await db
        .execute("CREATE TABLE salesorderdetail (id INTEGER PRIMARY KEY, orderid INTEGER, orderlineitem INTEGER, itemcode TEXT, itemname TEXT, qty INTEGER, itemunit TEXT, itemprice REAL, taxamount REAL, itemnotes TEXT, createddatetime NUMERIC DEFAULT (cast(strftime('%s','now') as int)), updateddatetime NUMERIC DEFAULT (cast(strftime('%s','now') as int)), active INTEGER DEFAULT 1)");
    await db
        .execute("insert into item(itemcode,itemname,itemunit,itemprice,taxpercent,available,active) values(null,'Group1',null,1.0,null,null,1)");
    await db
        .execute("insert into item(itemcode,itemname,itemunit,itemprice,taxpercent,available,active) values(null,'Group2',null,2.0,null,null,1)");
    await db
        .execute("insert into item(itemcode,itemname,itemunit,itemprice,taxpercent,available) values(null,'Group3',null,5.0,null,null)");//without value for active field
    await db
        .execute("insert into item(itemcode,itemname,itemunit,itemprice,taxpercent,available) values(null,'Group4',null,10.0,null,null)");//without value for active field
  }

  Future <Item> additem(Item item) async {
    var dbclient = await db;
    item.id = await dbclient.insert('item', item.toMap());
    return item;
  }

  Future<int> updateitem(Item item) async {
    var dbClient = await db;
    return await dbClient.update(
      'item',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<int> deleteitem(int id) async {
    var dbClient = await db;
    return await dbClient.delete(
      'item',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future <SalesOrder> addsalesorder(SalesOrder salesorder) async {
    var dbclient = await db;
    salesorder.id = await dbclient.insert('salesorder', salesorder.toMap());
    return salesorder;
  }

  Future <SalesOrderDetail> addsalesorderdetail(SalesOrderDetail salesorderdetail) async {
    var dbclient = await db;
    salesorderdetail.id = await dbclient.insert('salesorderdetail', salesorderdetail.toMap());
    return salesorderdetail;
  }

  Future close() async {
    var dbClient = await db;
    dbClient.close();
  }

  // All of the methods (insert, query, update, delete) can also be done using
  // raw SQL commands. This method uses a raw query to give the row count.
  Future<int> itemRowCount() async {
    var dbClient = await db;
    final count = Sqflite.firstIntValue(await dbClient.rawQuery('SELECT COUNT(*) FROM item'));
    return count;
  }

  Future <List<Item>> getallitems() async {
    var dbClient = await db;
    List<Map> maps=await dbClient.query('item');
    List<Item> items=[];
    if (maps.length>0){
      for (int i=0;i<maps.length;i++){
        items.add(Item.fromMap(maps[i]));
      }
    }
    return items;
  }

  Future <List<SalesOrder>> getallsalesorders() async {
    var dbClient = await db;
    List<Map> maps=await dbClient.query('salesorder');
    List<SalesOrder> salesorders=[];
    if (maps.length>0){
      for (int i=0;i<maps.length;i++){
        salesorders.add(SalesOrder.fromMap(maps[i]));
        //print('order: '+salesorders[i].toString());
      }
    }
    return salesorders;
  }

  Future <List<SalesOrder>> getsalesorder(int id) async {
    var dbClient = await db;
    List<Map> maps=await dbClient.query('salesorder',where: 'id = ?',whereArgs: [id],);
    List<SalesOrder> salesorder=[];
    if (maps.length>0){
      for (int i=0;i<maps.length;i++){
        salesorder.add(SalesOrder.fromMap(maps[i]));
      }
    }
    return salesorder;
  }

  Future <List<SalesOrderDetail>> getallsalesordersdetail() async {
    var dbClient = await db;
    List<Map> maps=await dbClient.query('salesorderdetail');
    List<SalesOrderDetail> salesordersdetail=[];
    if (maps.length>0){
      for (int i=0;i<maps.length;i++){
        salesordersdetail.add(SalesOrderDetail.fromMap(maps[i]));
        //print('order detail: ' + salesordersdetail[i].toString());
      }
    }
    return salesordersdetail;
  }

  Future <List<SalesOrderDetail>> getsalesorderdetail(int orderid) async {
    var dbClient = await db;
    List<Map> maps=await dbClient.query('salesorderdetail',where: 'orderid = ?',whereArgs:  [orderid], );
    List<SalesOrderDetail> salesorderdetail=[];
    if (maps.length>0){
      for (int i=0;i<maps.length;i++){
        salesorderdetail.add(SalesOrderDetail.fromMap(maps[i]));
        //print('order detail: ' + salesorderdetail[i].toString());
      }
    }
    return salesorderdetail;
  }
}