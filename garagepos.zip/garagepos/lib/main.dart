import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:garagepos/db/db_helper.dart';
import 'package:garagepos/model/cart_model.dart';
import 'package:garagepos/model/salesorder_model.dart';
import 'package:garagepos/model/salesorderdetail_model.dart';
import 'package:scoped_model/scoped_model.dart';
import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:another_brother/label_info.dart';
import 'package:another_brother/printer_info.dart' as brother;
import 'package:flutter_email_sender/flutter_email_sender.dart';
//app screens
import 'screens/appmenu.dart';
import 'screens/managestore.dart';
import 'screens/manageemail.dart';
import 'screens/manageprinter.dart';
import 'screens/items.dart';
import 'screens/neworder.dart';
import 'screens/cartpage.dart';
import 'screens/orders.dart';
import 'screens/vieworder.dart';
import 'screens/about.dart';

void main() {
  runApp(MyApp(
    model: CartModel(),
  ));
}

class MyApp extends StatelessWidget {
  final CartModel model;
  const MyApp({Key key, @required this.model}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ScopedModel<CartModel>(
      model: model,
      child: MaterialApp(
        title: 'Garage POS',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: '/',
        routes: {
          '/': (context)=>MyHomePage(title: 'Garage POS'),
          ManageStore.routename: (context) => ManageStore(),
          ManageEmail.routename: (context)=> ManageEmail(),
          ManagePrinter.routename: (context)=> ManagePrinter(),
          Items.routename:(context)=> Items(),
          NewOrder.routename:(context)=>NewOrder(),
          CartPage.routename:(context)=>CartPage(),
          Orders.routename: (context)=>Orders(),
          ViewOrder.routename:(context)=>ViewOrder(),
          About.routename:(context)=>About(),
        },
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  final dbHelper = DBHelper.instance;
  Future <List <SalesOrder>> salesorders;
  Future <List <SalesOrderDetail>> salesorderdetail;
  int _orderscount=0;
  double _orderstotal=0;

  @override
  void initState() {
    super.initState();
    dbHelper.initDatabase();
    setState(() {
      salesorders = dbHelper.getallsalesorders();
    });
  }

  void _fNewOrder() {
    Navigator.of(context).pushNamed(NewOrder.routename);
    setState(() {
      //state info
    });
  }

  String _ordertext(SalesOrder ordersummary,List <SalesOrderDetail> orderdetail){
    String ordsum='';
    ordsum='Garage POS'+'\n\n' +'Sale# '+ordersummary.id.toString()+'\n'+'Sold to: '+ordersummary.name + '\n'+ 'Dt: '+DateTime.fromMillisecondsSinceEpoch(ordersummary.orderdatetime).toString()+'\n\n';
    String orddtl='Item : Qty @ Price : Total'+'\n\n';
    for (int i=0;i<orderdetail.length;i++){
      orddtl=orddtl+orderdetail[i].itemname+' : '+orderdetail[i].qty.toString()+' @ \$'+orderdetail[i].itemprice.toString()+' : \$'+(orderdetail[i].qty*orderdetail[i].itemprice).toString()+'\n';
    }
    return (ordsum + '\n' + orddtl +'\n' + 'Order Total: \$' +ordersummary.ordertotal.toString() + '\n\n'+ 'Ref Notes: ' + ordersummary.notes); //orderdetail.toString()
  }

  void _showorderdetail(SalesOrder ordersummary,List <SalesOrderDetail> orderdetail){
    _ackAlert(context,_ordertext(ordersummary, orderdetail));
  }

  void _printorderdetail(SalesOrder ordersummary,List <SalesOrderDetail> orderdetail){
    String msg = _ordertext(ordersummary, orderdetail);
    printorder(msg);
    _showScaffold('Data sent to printer.');
  }

  void _showScaffold(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message),duration: Duration(seconds: 1),));
  }

  Future<void> _ackAlert(BuildContext context, String msg) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('View Order'),
          content: Text('$msg'),
          actions: <Widget>[
            IconButton(onPressed: () async {
              printorder(msg);
            }, icon: Icon(Icons.print),)
            ,IconButton(onPressed: () async {
              sendemail(msg);
            }, icon:Icon(Icons.email),)
            ,TextButton(
              child: Text('Ok'),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushNamed(context, '/');
              },
            ),
          ],
        );
      },
    );
  }

  Future<ui.Image> loadImage(String assetPath) async {
    final ByteData img = await rootBundle.load(assetPath);
    final Completer<ui.Image> completer = new Completer();
    ui.decodeImageFromList(new Uint8List.view(img.buffer), (ui.Image img) {
      return completer.complete(img);
    });
    return completer.future;
  }

  Future<void> sendemail(String msg) async {
    final Email email = Email(
      body: msg+'\n\n'+'For paying through paypal, use the email alias: garagepos@example.com.',
      subject: 'Your garage order',
      isHTML: false,
    );

    String platformResponse;

    try {
      await FlutterEmailSender.send(email);
      platformResponse = 'success';
    } catch (error) {
      platformResponse = error.toString();
    }

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(platformResponse),
      ),
    );
  }

  void printorder(String msg) async {

    var printer = new brother.Printer();
    var printInfo = brother.PrinterInfo();
    printInfo.printerModel = brother.Model.QL_820NWB;
    printInfo.printMode = brother.PrintMode.FIT_TO_PAGE;
    printInfo.isAutoCut = true;
    printInfo.port = brother.Port.NET;  //wi-fi
    printInfo.labelNameIndex = QL1100.ordinalFromID(QL1100.W62.getId()); //2.4 inch

    // Set the printer info so we can use the SDK to get the printers.
    await printer.setPrinterInfo(printInfo);

    // Get a list of printers with my model available in the network.
    List<brother.NetPrinter> printers = await printer.getNetPrinters([brother.Model.QL_820NWB.getName()]);

    if (printers.isEmpty) {
      // Show a message if no printers are found.
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("No printers found on your network."),
      ));

      return;
    }
    // Get the IP Address from the first printer found.
    printInfo.ipAddress = printers.single.ipAddress;

    printer.setPrinterInfo(printInfo);
    //printer.printImage(await loadImage('assets/images/garagepos.png'));

    //print text
    TextStyle style = TextStyle(
        color: Colors.black,
        fontSize: 20,
        fontWeight: FontWeight.bold
    );
    ui.ParagraphBuilder paragraphBuilder = ui.ParagraphBuilder(
        ui.ParagraphStyle(
          fontSize:   style.fontSize,
          fontFamily: style.fontFamily,
          fontStyle:  style.fontStyle,
          fontWeight: style.fontWeight,
          textAlign: TextAlign.center,
          maxLines: 30,
        )
    )
      ..pushStyle(style.getTextStyle())
      ..addText(msg);
    ui.Paragraph paragraph = paragraphBuilder.build()..layout(ui.ParagraphConstraints(width: 300));
    brother.PrinterStatus status = await printer.printText(paragraph);
    print("Got Status: $status and Error: ${status.errorCode.getName()}");
  return;
  }

  SingleChildScrollView _generateList (List<SalesOrder> salesorders) {
    return SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: SizedBox(
        width: MediaQuery.of(context).size.width,
          child: DataTable(
            columns: [
              DataColumn(label: Text('Order Info')),
              DataColumn(label: Text('Amount')),
              DataColumn(label: Text(''),)
            ],
            rows: salesorders.map((salesorder) => DataRow (
              cells: [
                DataCell(Text(
                  salesorder.id.toString() +' : '+ salesorder.name + "\n" + DateTime.fromMillisecondsSinceEpoch(salesorder.orderdatetime).toString()
                ),
                onTap: () async {
                  List <SalesOrderDetail> orderdetail = await dbHelper.getsalesorderdetail(salesorder.id);
                  _showorderdetail(salesorder,orderdetail);
                },
                ),
                DataCell(Text(salesorder.ordertotal.toString()),
                  onTap: () async {
                    List <SalesOrderDetail> orderdetail = await dbHelper.getsalesorderdetail(salesorder.id);
                    _showorderdetail(salesorder,orderdetail);
                  },),
                DataCell(IconButton(
                  icon: Icon(Icons.print),
                  onPressed: () async {
                    List <SalesOrderDetail> orderdetail = await dbHelper.getsalesorderdetail(salesorder.id);
                    _printorderdetail(salesorder, orderdetail);
                  },
                )),
              ],
            )
            ).toList(),
          ),
      ),
    );
  }

    @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      drawer: AppMenu(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Expanded(child: FutureBuilder(
             future: salesorders,
             builder: (context,snapshot) {
               if (snapshot.hasData) {
                 return (_generateList(snapshot.data));
               }
               if (snapshot.data == null || snapshot.data.length == 0) {
                 return Text('All the best for your garage sales.\nSummary of orders will be listed here.');
               }
               return CircularProgressIndicator();
             }
            )
            ),
            Expanded(child: FutureBuilder(
                future: salesorders,
                builder: (context,snapshot) {
                  List <SalesOrder> orders=snapshot.data;
                  int count=0;
                  double total=0;
                  for (int i=0;i<orders.length;i++){
                    count++;
                    total=total+orders[i].ordertotal;
                  }
                  return Text('Orders Count: '+count.toString()+'\n'+'Orders Total: \$'+total.toString(),textScaleFactor: 2,);
                }
            )
            ),
          ],
        ),
      ),
    floatingActionButton: FloatingActionButton(
      onPressed: _fNewOrder,
      tooltip: 'New Order',
      child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
