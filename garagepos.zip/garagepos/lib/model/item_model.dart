
class Item {
  int id;
  String itemcode;
  String itemname;
  String itemunit;
  double itemprice;
  double taxpercent;
  int available;
  int createddatetime;
  int updateddatetime;
  int active;

  Item(this.id,this.itemcode, this.itemname,this.itemunit,this.itemprice,this.taxpercent,this.available,this.createddatetime,this.updateddatetime,this.active);

  Map<String, dynamic> toMap() {
    var map = <String, dynamic> {
      'id': id,
      'itemcode':itemcode,
      'itemname':itemname,
      'itemunit':itemunit,
      'itemprice':itemprice,
      'taxpercent':taxpercent,
      'available':available,
      'createddatetime':createddatetime,
      'updateddatetime':updateddatetime,
      'active':active,
    };
    return map;
  }

  Item.fromMap(Map<String, dynamic> map) {
    id=map['id'];
    itemcode=map['itemcode'];
    itemname=map['itemname'];
    itemunit=map['itemunit'];
    itemprice=map['itemprice'];
    taxpercent=map['taxpercent'];
    available=map['available'];
    createddatetime=map['createddatetime'];
    updateddatetime=map['updateddatetime'];
    active=map['active'];
  }

  @override
  String toString() {
    return '$id : $itemcode : $itemname : $itemunit : $itemprice : $taxpercent : $available : $createddatetime : $updateddatetime : $active';
  }
}