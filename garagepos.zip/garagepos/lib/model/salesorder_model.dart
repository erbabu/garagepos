//salesorder (id INTEGER PRIMARY KEY, orderdatetime INTEGER DEFAULT (cast(strftime('%s','now') as int)), name TEXT, email TEXT, phone TEXT, notes TEXT, subtotal REAL, taxamount REAL, othercharges REAL, ordertotal REAL, updateddatetime INTEGER DEFAULT (cast(strftime('%s','now') as int)), active INTEGER DEFAULT 1)

import 'package:flutter/material.dart';

class SalesOrder {
  int id;
  int orderdatetime;
  String name;
  String email;
  String phone;
  String notes;
  double subtotal;
  double taxamount;
  double othercharges;
  double ordertotal;
  int updateddatetime;
  int active;

  SalesOrder(this.id,this.orderdatetime,this.name,this.email,this.phone,this.notes, this.subtotal,this.taxamount,this.othercharges,this.ordertotal,this.updateddatetime,this.active);

  Map<String, dynamic> toMap() {
    var map = <String, dynamic> {
      'id': id,
      'orderdatetime':orderdatetime,
      'name':name,
      'email':email,
      'phone':phone,
      'notes':notes,
      'subtotal':subtotal,
      'taxamount':taxamount,
      'othercharges':othercharges,
      'ordertotal':ordertotal,
      'updateddatetime':updateddatetime,
      'active':active,
    };
    return map;
  }

  SalesOrder.fromMap(Map<String, dynamic> map) {
    id=map['id'];
    orderdatetime=map['orderdatetime'];
    name=map['name'];
    email=map['email'];
    phone=map['phone'];
    notes=map['notes'];
    subtotal=map['subtotal'];
    taxamount=map['taxamount'];
    othercharges=map['othercharges'];
    ordertotal=map['ordertotal'];
    updateddatetime=map['updateddatetime'];
    active=map['active'];
  }

  @override
  String toString() {
    return '$id : $orderdatetime : $name : $email : $phone : $notes : $subtotal : $taxamount : $othercharges : $ordertotal : $updateddatetime : $active';
  }

}