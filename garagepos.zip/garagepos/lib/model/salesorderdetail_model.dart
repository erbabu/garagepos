//id INTEGER PRIMARY KEY, orderid INTEGER, orderlineitem INTEGER, itemcode TEXT, itemname TEXT, qty INTEGER, itemunit TEXT, itemprice REAL, taxamount REAL, itemnotes TEXT, createddatetime INTEGER, updateddatetime INTEGER, active INTEGER)

class SalesOrderDetail {
  int id;
  int orderid;
  int orderlineitem;
  String itemcode;
  String itemname;
  int qty;
  String itemunit;
  double itemprice;
  double taxamount;
  String itemnotes;
  int createddatetime;
  int updateddatetime;
  int active;

  SalesOrderDetail(this.id,this.orderid,this.orderlineitem,this.itemcode,this.itemname,this.qty,this.itemunit,this.itemprice,this.taxamount,this.itemnotes,this.createddatetime,this.updateddatetime,this.active);

  Map<String, dynamic> toMap() {
    var map = <String, dynamic> {
      'id': id,
      'orderid':orderid,
      'orderlineitem':orderlineitem,
      'itemcode':itemcode,
      'itemname':itemname,
      'qty':qty,
      'itemunit':itemunit,
      'itemprice':itemprice,
      'taxamount':taxamount,
      'itemnotes':itemnotes,
      'createddatetime':createddatetime,
      'updateddatetime':updateddatetime,
      'active':active,
    };
    return map;
  }

  SalesOrderDetail.fromMap(Map<String, dynamic> map) {
    id=map['id'];
    orderid=map['orderid'];
    orderlineitem=map['orderlineitem'];
    itemcode=map['itemcode'];
    itemname=map['itemname'];
    qty=map['qty'];
    itemunit=map['itemunit'];
    itemprice=map['itemprice'];
    taxamount=map['taxamount'];
    itemnotes=map['itemnotes'];
    createddatetime=map['createddatetime'];
    updateddatetime=map['updateddatetime'];
    active=map['active'];
  }

  @override
  String toString() {
    return '$id : $orderid : $orderlineitem : $itemcode : $itemname : $qty : $itemunit : $itemprice : $taxamount : $itemnotes : $createddatetime : $updateddatetime : $active';
  }

}