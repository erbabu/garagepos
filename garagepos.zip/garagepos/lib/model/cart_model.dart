import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';

class Record {
  int id;
  String itemname;
  double itemprice;
  int qty = 1;

  Record(this.id,this.itemname,this.itemprice,this.qty);

  Map<String, dynamic> toMap() {
    var map = <String, dynamic> {
      'id': id,
      'itemname':itemname,
      'itemprice':itemprice,
      'qty':qty,
    };
    return map;
  }

  Record.fromMap(Map<String, dynamic> map) {
    id=map['id'];
    itemname=map['itemname'];
    itemprice=map['itemprice'];
    qty=map['qty'];
  }

  @override
  String toString() {
    return '$id : $itemname : $itemprice : $qty';
  }
}

class CartModel extends Model {
  List<Record> cart = [];
  double totalCartValue = 0;

  int get total => cart.length;

  /// Wraps [ScopedModel.of] for this [Model].
  static CartModel of(BuildContext context) =>
      ScopedModel.of<CartModel>(context);

  void addProduct(product) {
    int index = cart.indexWhere((i) => i.id == product.id);
    print(index);
    if (index != -1)
      updateProduct(product, product.qty + 1);
    else {
      cart.add(product);
      calculateTotal();
      notifyListeners();
    }
  }

  void removeProduct(product) {
    int index = cart.indexWhere((i) => i.id == product.id);
    print(index);
    if (index != -1)
      updateProduct(product, product.qty - 1);
  }

  void updateProduct(product, qty) {
    if (qty == 0) {cart.removeWhere((item) => item.id == product.id);}
    else {
      int index = cart.indexWhere((i) => i.id == product.id);
      cart[index].qty = qty;
      calculateTotal();
      notifyListeners();
    }
  }

  void clearCart() {
    cart.forEach((f) => f.qty = 1);
    cart = [];
    notifyListeners();
  }

  void calculateTotal() {
    totalCartValue = 0;
    cart.forEach((f) {
      totalCartValue += f.itemprice * f.qty;
    });
  }
}